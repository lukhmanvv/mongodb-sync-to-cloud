# mongodb-sync-to-cloud
sync local mongodb to cloud database when internet is available
installation

1. npm install
2. create .env with following configurations
MONGO_CLOUD_URL = 
MONGO_CLOUD_DATABSE = 
MONGO_CLOUD_COLLECTION_SALES = 
MONGO_CLOUD_COLLECTION_COLLECTION =
MONGO_LOCAL_URL = mongodb://localhost:27017/
RESOLVED_ADDRESS = www.google.com
APP_PORT = 

SET_TIMEOUT =

this is for cloud database setup

3. local database configuration in .env and collections managed by mongoose schema
